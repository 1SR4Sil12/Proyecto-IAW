from django.apps import AppConfig


class AcogemAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AcogeM_app'

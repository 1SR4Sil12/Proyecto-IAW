
#def localizacion_imagen(instance, filename):
#	return .../%.png % (instance.id)
